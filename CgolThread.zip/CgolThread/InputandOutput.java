package CgolThread;

public class InputandOutput extends Thread {
	
	private int r, c;
	private int[][] arr ;
	private int[][] NextLife = new int[200][200];

	public InputandOutput(int r, int c, int[][] arr) {
		this.r=r;
		this.c=c;
		this.arr = arr;
	}
	
	public void run() {
		//Calculating the time elapsed so far.
		
		int i,j,k,l;

		
		for(i=1; i<r-1; i++){                         // Loop through every cell of the every row and column
			for(j=1; j<c-1; j++){

				
				int aliveCell = 0;
				for(k=-1; k<=1; k++)                  //Find the alive cell
					for(l=-1; l<=1; l++)
						aliveCell = aliveCell + arr[i+k][j+l];

				aliveCell = aliveCell - arr[i][j];

				
				if((arr[i][j] == 1) && (aliveCell < 2)){
					NextLife[i][j] = 0;                                       //If a cell is lonely alive,It will die
				}

			
				else if((arr[i][j] == 1) && (aliveCell > 3)){                  //If a cell has more than three neighbour,It will die
                                                                         // due to over population.
					NextLife[i][j] = 0;
				}

			
				else if((arr[i][j] == 0) && (aliveCell ==3)){                  //If a cell has three neighbour,It will born 
                                                                             // due to reproduction.
					NextLife[i][j] = 1;
				}

				
				else{
					NextLife[i][j] = arr[i][j];                   //Rest Keep same
				}
			}
		}

		System.out.println();
		System.out.println("Next Life:");

		// Printing the next life
		for(k=0; k<r; k++){
			for(l=0; l<c; l++){
				System.out.print(NextLife[k][l] + " ");
			}
			System.out.println();
		}
		
		
		for (k = 0; k < r; k++) {
			for (l = 0; l < c; l++) {
				arr[k][l] = NextLife[k][l];         //Assinging for further Generation
			}
		}
		long StartTime = System.nanoTime();
		 long endTime = System.nanoTime();
		    long time = (endTime - StartTime);           //Calculate the execution Time
        System.out.println("Execution time: " + time + " ns");
        System.out.println("Enter the Y for continue and N for stop: ");
	}

}
