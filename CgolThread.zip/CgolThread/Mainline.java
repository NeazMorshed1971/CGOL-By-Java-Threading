package CgolThread;

import java.util.Scanner;

/**
 * 
 * Description : Program of CGOL by using Java Multithreading
 * 
 * 
 * @author Neaz Morshed
 * 
 * @version 1.00 All rules of CGOL
 *
 */
public class Mainline {

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);        //Take input from the user
		
	
		int r, c;                                    //Define variables
		char run;
		System.out.println("Enter the no of rows");          //Take row from the user
		
		r = in.nextInt();                                     // Put that number row variable

		System.out.println("Enter the no of Columns");           // Take number of colomns from the user
	
		c = in.nextInt();                                         //Put that number of in colomn variable
		
		//Declaring the Arrays which will store the intial CGOL
		int[][] arr = new int[r][c];

		System.out.println("Enter 1 as alive cell and 0 as dead cell"); // Basic rule of CGOL
		System.out.println("Enter the CGOL:");                //Take user input for the initial generation
	
		
		for (int i = 0; i < r; i++) {                 //initial generation
			for (int j = 0; j < c; j++) {
				arr[i][j] = in.nextInt();
			}
		}
		

		
		//When user input Y it will continue
		do {
		
			InputandOutput s = new InputandOutput(r,c,arr);
			
			s.start();            //Executing thread
		
			s.setPriority(4);      //Set Priority 
			
			run = in.next().charAt(0);
		} while (run == 'Y');

		
		if(run == 'N') {                                      //When the user input N the loop will stop
			System.out.println("Thank You!");			
		}
		in.close();
	}

}
